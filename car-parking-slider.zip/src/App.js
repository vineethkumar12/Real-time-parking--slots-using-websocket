
import './App.css';

import { Carosule } from './Carosule';
function App() {
  return (
    <div className="App">
       <Carosule/>
    </div>
  );
}

export default App;
