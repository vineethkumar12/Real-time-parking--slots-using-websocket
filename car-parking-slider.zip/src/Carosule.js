import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import './Carosule.css'

import { useEffect,useState } from "react";

export const Carosule = () => { 
  const [socket, setSocket] = useState(null);
    const [message, setMessage] = useState('');
    const [receivedMessages, setReceivedMessages] = useState([]);
  //const [parkingSlots, setParkingSlots] = useState([{}]);
    useEffect(() => {
      const newSocket = new WebSocket('ws://localhost:3001');
  
      newSocket.addEventListener('open', () => {
        console.log('Connected to WebSocket server');
        setSocket(newSocket);
      });
  
      newSocket.addEventListener('message', (event) => {
        console.log('Received message:', event.data);
        setReceivedMessages([...receivedMessages, event.data]);
      });
  
      newSocket.addEventListener('close', () => {
        console.log('Disconnected from WebSocket server');
      });
  
      return () => {
        newSocket.close();
      };
    }, [receivedMessages]);
  
    
  
 
    const parkingSlots = [
        { "slotName": "A", "isParked": true },
        { "slotName": "B", "isParked": false },
        { "slotName": "C", "isParked": true },
        { "slotName": "D", "isParked": false },
        { "slotName": "E", "isParked": true },
        { "slotName": "F", "isParked": false },
        { "slotName": "G", "isParked": true },
        { "slotName": "H", "isParked": false },
        { "slotName": "I", "isParked": true },
        { "slotName": "J", "isParked": false },
        { "slotName": "K", "isParked": true },
        { "slotName": "L", "isParked": false },
        { "slotName": "M", "isParked": true },
        { "slotName": "N", "isParked": false },
        { "slotName": "O", "isParked": true },
       
      ];
      
   
      



  const settings = {
   
    infinite: true,
    speed: 5000,
    autoplay: true,
    autoplaySpeed: 3000, 
    slidesToScroll: 1,
  };
  

  return (
    <div className="carosule">
      
    
      <Slider {...settings}>
      <div >
        <div id="parent">
            <div className="child1" >
               <h1>▀▄▀▄▀▄ BLOCK-1 ▄▀▄▀▄▀</h1>
            </div>
            <div className="book">
            {
                parkingSlots.map((value,index)=>{
                       
                
                return (
                    
                 
                 
                   <div  className='b2' id={value.slotName}    style={{background:(value.isParked)?'rgba(173,248,2,0.6)':"rgba(249, 105, 14,0.6)",border:(value.isParked)?'4px solid rgba(173,248,2,1.00)':"4px solid rgba(249, 105, 14)"}}   key={index} >{value.slotName}</div> 
                  
                )
           
                    
                    
                })
            }
            
            </div>
        </div>
      </div>

      <div>
        <div id="parent">
            <div className="child1">
               <h1>▀▄▀▄▀▄ BLOCK-1 ▄▀▄▀▄▀</h1>
            </div>
          <div className="child2">
              <h1 style={{marginLeft:"-20px"}}> Total Slots   :  15</h1>
              <h1 style={{marginLeft:"30px"}}> Available Slots : 12</h1>
              <h1> Parked Slots       :   03</h1>
            </div>
        </div>
      </div>
      
     
    </Slider>
    </div>
 
  );
};

